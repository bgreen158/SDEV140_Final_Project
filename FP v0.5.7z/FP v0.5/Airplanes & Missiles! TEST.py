###################################################
#Program Name: Airplanes & Missiles!
#Program Author: Ben Green
#Program Version: 0.3
###################################################

#Program Start
#Import tkinter and random
from tkinter import *
from random import *

#Set up controls for moving airplane
#Up, down, left, and right are set to WASD and arrow keys.
def updateDir():
    global up
    global down
    global right
    global right
    global w
    global s
    global d
    global a
    if up == 1 or w == 1:
        c.move(spaceship, 0, -3)
    elif down == 1 or s == 1:
        c.move(spaceship, 0, 3)
    elif right == 1 or d == 1:
        c.move(spaceship, 3, 0)
    elif left == 1 or a == 1:
        c.move(spaceship, -3, 0)
    window.after(10, updateDir)

#Create event for controls
def getDir(event):
    global up
    global down
    global right
    global left
    global w
    global s
    global d
    global a
    key = event.keysym
    if key == "w":
        w = 1
    elif key == "s":
        s = 1
    elif key == "d":
        d = 1
    elif key == "a":
        a = 1
    elif key == "Up":
        up = 1
    elif key == "Down":
        down = 1
    elif key == "Right":
        right = 1
    elif key == "Left":
        left = 1

#Create event for when key press has stopped, thus halting controls.
def stopDir(event):
    global up
    global down
    global right
    global left
    global w
    global s
    global d
    global a
    key = event.keysym
    if key == "w":
        w = 0
    elif key == "s":
        s = 0
    elif key == "d":
        d = 0
    elif key == "a":
        a = 0
    if key == "Up":
        up = 0
    elif key == "Down":
        down = 0
    elif key == "Right":
        right = 0
    elif key == "Left":
        left = 0

#Create collision between item1 and item2 based on distance
def collision(item1, item2, distance):
    xdistance = abs(c.coords(item1)[0] - c.coords(item2)[0])
    ydistance = abs(c.coords(item1)[1] - c.coords(item2)[1])
    overlap = xdistance < distance and ydistance < distance
    return overlap

#Check laser with collision to see if the laser hits
def checkLaser():
    global distance
    for i in laserList:
        for rock in rockList:
            if collision(i, rock, distance):
                updateScore()
                c.delete(rock)
                rockList.remove(rock)
                c.delete(i)
                laserList.remove(i)
                break
    window.after(1, checkLaser)

#Update Score module
def updateScore():
    global score
    global level
    global lives
    global stuff

    #Score goes up by 1 each time a missile is hit by a laser
    #Player gets extra lives after score hits certain thresholds
    score = score + 1
    if score == 25:
        stuff = stuff - 10
        level = 15
        lives = lives + 1
        llives.config(text = "Lives: " + str(lives))
    elif score == 50:
        stuff = stuff - 10
        level = 20
        lives = lives + 1
        llives.config(text = "Lives: " + str(lives))
    elif score == 75:
        stuff = stuff - 10
        level = 25
        lives = lives + 1
        llives.config(text = "Lives: " + str(lives))
    elif score == 100:
        stuff = stuff - 10
        level = 30
        lives = lives + 1
        llives.config(text = "Lives: " + str(lives))
    elif score == 125:
        stuff = stuff - 10
        level = 35
        lives = lives + 1
        llives.config(text = "Lives: " + str(lives))
    elif score == 150:
        stuff = stuff - 10
        level = 40
        lives = lives + 1
        llives.config(text = "Lives: " + str(lives))
    elif score == 175:
        stuff = stuff - 10
        level = 45
        lives = lives + 1
        llives.config(text = "Lives: " + str(lives))
    elif score == 200:
        stuff = stuff - 10
        level = 50
        lives = lives + 1
        llives.config(text = "Lives: " + str(lives))
    try:
        lscore.config(text = "Score: " + str(score))
    except:
        pass

#When plane is hit by missile, you lose 1 life
#When lives reaches "0" is is game over
def updateLives():
    global lives
    if lives == 1:
        endGame()
    else:
        lives = lives - 1
        try:
            llives.config(text = "Lives: " + str(lives))
        except:
            pass

#Close Game after "Game Over"
#Display High score after 5000 units
def endGame():
    global score
    Gameover = c.create_text(375,150,text="Game Over",fill="white",font=('Times New Roman',30))
    Score = c.create_text(375, 300, text = "Final Score: " + str(score), fill = "white", font = ('Times New Roman', 30))
    Stopwatch.destroy()
    llives.destroy()
    lscore.destroy()
    window.after(5000, close)
#Close window
def close():
    window.destroy()

#checking collision with airplane
#remove missile object when it collides with plane
def checkCollisions():
    for i in rockList:
        if collision(i,spaceship,30):
            updateLives()
            c.delete(i)
            rockList.remove(i)                
    window.after(1, checkCollisions)

def updateTimer():
    global gametime
    gametime = gametime + 1
    try:
        Stopwatch.config(text = "Time: " + str(gametime))
    except:
        pass
    window.after(1000, updateTimer)
def endTitle():
    c.delete(Text)
    c.delete(TText)
    c.delete(TTText)
    c.delete(TTTText)

#Create missile objects randomly on the screen
def makeSteroid():
    global stuff
    x = randint(0,750)
    rock = c.create_image(200, 200, image = Asteroid)
    c.coords(rock, x, 0)
    rockList.append(rock)
    window.after(stuff, makeSteroid)

#Move missiles from top of screen towards the bottom on the y axis.
#Remove missile when it passes the bottom of the screen
def moveSteroid():
    global level
    for i in rockList:
        rand = randint(1, 750)
        c.move(i, 0, level)
        pos = c.coords(i)
        y = pos[1]
        if y >= 500:
            c.delete(i)
            rockList.remove(i)
    window.after(100, moveSteroid)

#Create laser texture that fires from the spaceship
#Laser is a red rectangle fireing vertically from the center of the ship
def shoot(event):
    pos=c.coords(spaceship)
    x= pos[0]
    y= pos[1]
    Laser = c.create_rectangle(x,y-10,x+2,y-50,fill="red")
    laserList.append(Laser)
#Laser moves towards the top of the screen from the position of the plane
#Laser is removed when it reaches the top of the screen without hitting anything else.
def moveLaser():
    for laser in laserList:
        c.move(laser, 0, -20)
        pos = c.coords(laser)
        y = pos[1]
        if y <= 0:
            c.delete(laser)
            laserList.remove(laser)
    window.after(100, moveLaser)
#Display title
window = Tk()
window.title("Airplanes & Missiles!!!")
window.config(bg = "Black")
gametime=0
#score set to 0 at start
score=0
#Lives set to 3 at start
lives=3
#Controls are set to neutral position at the start
up = 0
down = 0
left = 0
right = 0
w = 0
s = 0
d = 0
a = 0
Stopwatch = Label(window,text="Time:"+str(gametime),font=("Times New Roman",15), bg = "Black")
Stopwatch.pack()
lscore = Label(window,text="Score:"+str(score),font=("Times New Roman",15), bg = "Black", fg = "White")
lscore.pack()
llives = Label(window,text="Lives:"+str(lives),font=("Times New Roman",15), bg = "Black", fg = "White")
llives.pack()
c = Canvas(window, width = 750, height = 500, bg = "blue")
c.pack()
laserList=[]
Text=c.create_text(375,150,text="Airplanes & Missiles!!!",fill="white",font=('Times New Roman',30))
TText=c.create_text(375,175,text="Shoot as many missiles down as you can before you run out of lives!",fill="white",font=('Times New Roman',10))
TTText=c.create_text(375,200,text="Arrow Keys or WASD to Move",fill="white",font=('Times New Roman',8))
TTTText=c.create_text(375,225,text="Space or Left Click to Shoot",fill="white",font=('Times New Roman',8))
ship = PhotoImage(file = "Airplane.gif")
spaceship = c.create_image(362.5, 450, image = ship)
Asteroid = PhotoImage(file = "Missile.gif")
c.bind_all('<KeyPress>', getDir)
c.bind_all('<KeyRelease>', stopDir)
window.bind("<space>", shoot)
window.bind("<Button-1>", shoot)
rockList = []
gametime = 0
level = 10
distance = 17.5
stuff = 200
updateDir()
window.after(5000,endTitle)
window.after(1000, updateTimer)
window.after(stuff, makeSteroid)
window.after(1, moveSteroid)
window.after(1, moveLaser)
window.after(1, checkCollisions)
window.after(1, checkLaser)
window.mainloop()
